--------------INTEGRANTES---------------------
-Bogajo López, María
-Corral Martín, Ander
-López Sánchez, Peio
-Cotano Romero, Aitor

------------Análisis de Alojamiento en Airbnb: España vs. Portugal-----------------------

+Precio vs. Satisfacción: Analiza la relación entre el precio medio de los alojamientos y la puntuación de satisfacción otorgada por los usuarios. Se incluye una línea de tendencia para detectar posibles correlaciones.

+Mapa de distribución de satisfacción (correlación geográfica): Muestra la localización de las propiedades en un mapa con coloración según el equilibrio entre precio y satisfacción, identificando zonas fuertes o problemáticas.

+Mapa de calor por sentimiento: Representa en un mapa geográfico el sentimiento medio de las reseñas (positivo, neutro o negativo) por propiedad, para observar áreas con mejor o peor percepción.

+Evolución de la satisfacción (por año y por mes): Analiza cómo ha variado la puntuación media de satisfacción en España y Portugal a lo largo del tiempo. Incluye tendencias anuales y estacionales.

+Valoraciones positivas vs. negativas: Compara el volumen de reseñas positivas y negativas registradas por año y por mes, detectando cambios en la percepción general de los usuarios.

+Impacto de tasas adicionales (limpieza y depósito): Evalúa si el importe de la tasa de limpieza o del depósito de seguridad influye en la satisfacción media del cliente.

+Relación calidad/precio por tipo de alojamiento: Establece un umbral objetivo para determinar qué propiedades cumplen con una buena relación calidad/precio, agrupado por tipo de alojamiento y tipo de habitación.

+Distribución de puntuaciones por sentimiento: Muestra la puntuación media final asignada a reseñas etiquetadas como positivas, negativas o neutras, a fin de evaluar su coherencia.

+Palabras más frecuentes: Presenta las palabras más repetidas en reseñas positivas y negativas, diferenciadas por país y sentimiento, lo que permite identificar puntos fuertes y débiles en la experiencia del cliente.

+Word Cloud: Visualiza mediante una nube de palabras los términos más utilizados en reseñas positivas y negativas, facilitando una interpretación rápida y cualitativa del contenido.

